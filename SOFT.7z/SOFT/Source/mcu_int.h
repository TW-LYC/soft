/* Copyright (c) all rights reserved
*******************************************************************************
* @file    mcu_int.h
* @author  wangxq
* @version v1.0.1
* @date    2020-04-23
* @brief   
*******************************************************************************
* @attention
*
* #include "mcu_int.h"
*
*******************************************************************************
*/
#include "global.h"
#ifndef __MCU_INT__H
#define __MCU_INT__H


extern void MCU_IntInit(void);



#endif //__MCU_INT__H
