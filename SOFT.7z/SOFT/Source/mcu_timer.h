/* Copyright (c) all rights reserved
*******************************************************************************
* @file    mcu_timer.h
* @author  wangxq
* @version v1.0.1
* @date    2020-04-23
* @brief   
*******************************************************************************
* @attention
*
* #include "mcu_timer.h"
*
*******************************************************************************
*/
#include "global.h"
#ifndef __MCU_TIMER__H
#define __MCU_TIMER__H


extern void MCU_TimerInit(void);



#endif //__MCU_TIMER__H
